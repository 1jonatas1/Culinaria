package culinaria.example.dispositivosmoveis.culinaria;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Culinaria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_culinaria);
    }
}
